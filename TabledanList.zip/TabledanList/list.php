<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List</title>
</head>
<body>
    <h3>The ingredient:  </h3>
    <ul>
        <li>10g. flour</li>
        <li>10g. sugar</li>
        <li>1 cup water</li>
        <li>2 eggs</li>
        <li>salt,pepper</li>
    </ul>
    
    <h3>The procedure:</h3>
    <ol type="1">
        <li>Mix dry ingedients throguhtly</li>
        <li>pour in wet ingredients</li>
        <li>Mix for 10 minutes</li>
        <li>2 eggs</li>
        <li>Bake for one hour at 3000 degrees</li>
    </ol>
    
    <h3>Notes:</h3>
    <ol>
        <li>Mix dry ingedients throguhtly</li>
    </ol>



</body>
</html>