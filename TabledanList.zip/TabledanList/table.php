<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table</title>
</head>
<body>
    <table border="1" width="40%" height="200px">
        <caption>A test table with merged cells</caption>
        <thead>
            <tr>
                <th rowspan="2"></th>
                <th colspan="2">Average</th>
                <th rowspan="2">Red Eyes</th>
            </tr>
            <tr>
                <th>Height</th>
                <th>Weight</th>
            </tr>

        </thead>
        <tbody align="center">
            <tr>
                <th>Males</th>
                <td>1.9</td>
                <td>0.003</td>
                <td>40%</td>
            </tr>
            <tr>
                <th>Females</th>
                <td>1.7</td>
                <td>0.009</td>
                <td>43%</td>
            </tr>
        </tbody>

    </table>
</body>
</html>